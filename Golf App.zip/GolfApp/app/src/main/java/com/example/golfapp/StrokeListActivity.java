package com.example.golfapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class StrokeListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_stroke_list);
    }
}